/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package util;

import restaurante.RestauranteDAO;
import restaurante.RestauranteDAOHibernate;
import usuario.*;

/**
 *
 * @author marcos
 */
public class DAOFactory {

    public static UsuarioDAO criarUsuarioDAO() {
        UsuarioDAOHibernate usuarioDAO = new UsuarioDAOHibernate();
        usuarioDAO.setSession(HibernateUtil.getSessionFactory().getCurrentSession());
        return usuarioDAO;
    }

    public static RestauranteDAO criarRestauranteDAO() {
        RestauranteDAOHibernate restauranteDAO = new RestauranteDAOHibernate();
        restauranteDAO.setSession(HibernateUtil.getSessionFactory().getCurrentSession());
        return restauranteDAO;
    }

}
