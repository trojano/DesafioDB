/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package web;

import java.util.List;
import javax.faces.application.FacesMessage;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.RequestScoped;
import javax.faces.context.FacesContext;
import restaurante.Restaurante;
import restaurante.RestauranteRN;
import util.Resultado;

/**
 *
 * @author marcos
 */
@ManagedBean(name = "restauranteBean")
@RequestScoped
public class RestauranteBean {

    private Restaurante restaurante;

    public RestauranteBean() {
        this.restaurante = new Restaurante();

    }

    public Restaurante getRestaurante() {
        return restaurante;
    }

    public void setRestaurante(Restaurante restaurante) {
        this.restaurante = restaurante;
    }

    public String cadastrar() {

        FacesContext context = FacesContext.getCurrentInstance();

        RestauranteRN restauranteRN = new RestauranteRN();

        if (restauranteRN.buscarPorNome(this.restaurante.getNome()) != null) {
            FacesMessage facesMessage = new FacesMessage("Esse restaurante já consta no cadastro");
            context.addMessage(null, facesMessage);
            return null;
        }

        this.restaurante.setAtivo(true);
        restauranteRN.salvar(this.restaurante);

        return "index";
    }

    public List<Restaurante> listaRestaurantes() {

        FacesContext context = FacesContext.getCurrentInstance();
        RestauranteRN restauranteRN = new RestauranteRN();
        List<Restaurante> lrest = restauranteRN.listarRestaurantes();
        return lrest;
    }

    public String encerra() {

        FacesContext context = FacesContext.getCurrentInstance();
        RestauranteRN restauranteRN = new RestauranteRN();
        restauranteRN.encerra();

        return "index";
    }

    public List<Resultado> result() {
        FacesContext context = FacesContext.getCurrentInstance();
        RestauranteRN restauranteRN = new RestauranteRN();
        return restauranteRN.listarResultado();
    }

    public String logoff() {

        return "index";
    }

}
