/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package web;

import javax.faces.application.FacesMessage;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;
import javax.faces.context.FacesContext;
import usuario.Usuario;
import usuario.UsuarioRN;

/**
 *
 * @author marcos
 */
@ManagedBean(name = "usuarioBean")
@SessionScoped
public class UsuarioBean {

    private Usuario usuario;
    private String confirmaSenha;

    public UsuarioBean() {
        this.usuario = new Usuario();
    }

    public String login() {

        FacesContext context = FacesContext.getCurrentInstance();

        Usuario us;
        UsuarioRN usuarioRN = new UsuarioRN();
        us = usuarioRN.buscarPorUsername(this.usuario.getUsername());

        if (us == null) {

            FacesMessage facesMessage = new FacesMessage("Usuário não cadastrado");
            context.addMessage(null, facesMessage);
            return null;
        }

        if (!us.getSenha().equals(this.usuario.getSenha())) {

            FacesMessage facesMessage = new FacesMessage("Senha incorreta");
            context.addMessage(null, facesMessage);
            return null;
        }
        this.setUsuario(us);
        return "votacao";
    }

    public String salvar() {

        FacesContext context = FacesContext.getCurrentInstance();

        String senha = this.usuario.getSenha();

        if (!senha.equals(this.confirmaSenha)) {
            FacesMessage facesMessage = new FacesMessage("A senha não foi confirmada corretamente");
            context.addMessage(null, facesMessage);
            return null;
        }

        this.usuario.setAtivo(true);

        UsuarioRN usuarioRN = new UsuarioRN();
        usuarioRN.salvar(this.usuario);

        return "index";
    }

    public Usuario getUsuario() {
        return usuario;
    }

    public void setUsuario(Usuario usuario) {
        this.usuario = usuario;
    }

    public String getConfirmaSenha() {
        return confirmaSenha;
    }

    public void setConfirmaSenha(String confirmaSenha) {
        this.confirmaSenha = confirmaSenha;
    }

    public String votar(int rst) {

        FacesContext context = FacesContext.getCurrentInstance();

        UsuarioRN usuRN = new UsuarioRN();
        usuRN.votar(rst, usuario.getIdPessoa());

        return "resultado";
    }

    public String reinicia() {

        FacesContext context = FacesContext.getCurrentInstance();

        UsuarioRN usuRN = new UsuarioRN();

        usuRN.reinicia();

        return "votacao";
    }

}
