/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package usuario;

import java.util.List;
import restaurante.Restaurante;
import restaurante.RestauranteDAO;
import util.DAOFactory;

/**
 *
 * @author marcos
 */
public class UsuarioRN implements UsuarioDAO {

    private UsuarioDAO usuarioDAO;
    private RestauranteDAO restauranteDAO;

    public UsuarioRN() {
        this.usuarioDAO = DAOFactory.criarUsuarioDAO();
        this.restauranteDAO = DAOFactory.criarRestauranteDAO();
    }

    @Override
    public Usuario carregar(int idUsu) {
        return this.usuarioDAO.carregar(idUsu);
    }

    @Override
    public Usuario buscarPorNome(String nome) {
        return this.usuarioDAO.buscarPorNome(nome);
    }

    @Override
    public void salvar(Usuario usuario) {
        this.usuarioDAO.salvar(usuario);
    }

    @Override
    public void excluir(Usuario usuario) {
        this.usuarioDAO.excluir(usuario);
    }

    @Override
    public void atualizar(Usuario usuario) {
        this.usuarioDAO.atualizar(usuario);
    }

    public void votar(int rst, int usu) {

        Usuario u = this.usuarioDAO.carregar(usu);               
        u.setRestaurante(rst);
        this.usuarioDAO.atualizar(u);
    }

    @Override
    public Usuario buscarPorUsername(String username) {
        return this.usuarioDAO.buscarPorUsername(username);
    }

    public void reinicia() {

        List<Usuario> lusu = restauranteDAO.listarUsuarios();

        List<Restaurante> lres = restauranteDAO.listarRestaurantesInativos();
        System.out.println(lres);

        for (Usuario u : lusu) {
            u.setRestaurante(0);
            atualizar(u);
        }

        for (Restaurante r : lres) {
            r.setAtivo(true);
            restauranteDAO.atualizar(r);
        }

    }

}
