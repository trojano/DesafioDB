/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package usuario;

import org.hibernate.Query;
import org.hibernate.Session;

/**
 *
 * @author marcos
 */
public class UsuarioDAOHibernate implements UsuarioDAO {

    private Session session;

    public void setSession(Session session) {
        this.session = session;
    }

    @Override
    public void salvar(Usuario usuario) {
        this.session.save(usuario);
    }

    @Override
    public void atualizar(Usuario usuario) {
        this.session.update(usuario);
    }

    @Override
    public void excluir(Usuario usuario) {
        this.session.delete(usuario);
    }

    @Override
    public Usuario carregar(int idUsu) {
        String hql = "select u from Usuario u where u.idPessoa = :idUsu";
        Query consulta = (Query) this.session.createQuery(hql);
        consulta.setParameter("idUsu", idUsu);
        return (Usuario) consulta.uniqueResult();
    }

    @Override
    public Usuario buscarPorNome(String nome) {
        String hql = "select u from Usuario u where u.nome = :nome";
        Query consulta = (Query) this.session.createQuery(hql);
        consulta.setParameter("nome", nome);
        return (Usuario) consulta.uniqueResult();
    }

    @Override
    public Usuario buscarPorUsername(String username) {
        String hql = "select u from Usuario u where u.username = :username";
        Query consulta = (Query) this.session.createQuery(hql);
        consulta.setParameter("username", username);
        return (Usuario) consulta.uniqueResult();
    }

}
