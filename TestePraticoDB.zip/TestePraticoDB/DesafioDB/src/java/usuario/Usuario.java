/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package usuario;

import java.io.Serializable;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 *
 * @author marcos
 */
@Entity
@Table(name = "usuario")
public class Usuario implements Serializable {

    private static final long serialVersionUID = 4657555314839432900L;

    @Id
    @GeneratedValue
    private int idPessoa;
    private String nome;
    @org.hibernate.annotations.NaturalId
    private String username;
    private String senha;
    private boolean ativo;
    private int idRestaurante;

    public int getIdPessoa() {
        return idPessoa;
    }

    public void setIdPessoa(int idPessoa) {
        this.idPessoa = idPessoa;
    }

    public int getRestaurante() {
        return idRestaurante;
    }

    public void setRestaurante(int restaurante) {
        this.idRestaurante = restaurante;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getSenha() {
        return senha;
    }

    public void setSenha(String senha) {
        this.senha = senha;
    }

    public boolean isAtivo() {
        return ativo;
    }

    public void setAtivo(boolean ativo) {
        this.ativo = ativo;
    }

    @Override
    public String toString() {
        return "Usuario{" + "idPessoa=" + idPessoa + ", nome=" + nome + ", username=" + username + ", senha=" + senha + ", ativo=" + ativo + ", idRestaurante=" + idRestaurante + '}';
    }

}
