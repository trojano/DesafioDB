/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package restaurante;

import java.util.ArrayList;
import java.util.List;
import usuario.Usuario;
import usuario.UsuarioDAO;
import util.DAOFactory;
import util.Resultado;

/**
 *
 * @author marcos
 */
public class RestauranteRN implements RestauranteDAO {

    private RestauranteDAO restauranteDAO;
    private UsuarioDAO usuarioDAO;

    public RestauranteRN() {
        this.restauranteDAO = DAOFactory.criarRestauranteDAO();
        this.usuarioDAO = DAOFactory.criarUsuarioDAO();
    }

    @Override
    public void salvar(Restaurante rest) {
        this.restauranteDAO.salvar(rest);
    }

    @Override
    public void atualizar(Restaurante rest) {
        this.restauranteDAO.atualizar(rest);
    }

    @Override
    public void excluir(Restaurante rest) {
        this.restauranteDAO.excluir(rest);
    }

    @Override
    public Restaurante buscarPorNome(String nome) {
        return this.restauranteDAO.buscarPorNome(nome);
    }

    @Override
    public List<Usuario> listarUsuarios() {
        return this.restauranteDAO.listarUsuarios();
    }

    @Override
    public List<Restaurante> listarRestaurantes() {
        return this.restauranteDAO.listarRestaurantes();
    }

    @Override
    public int listarVotos(int restaurante) {
        return this.restauranteDAO.listarVotos(restaurante);
    }

    public List<Resultado> listarResultado() {
        List<Resultado> resultlist = new ArrayList<>();

        List<Restaurante> res = listarRestaurantes();
        int votos;

        for (Restaurante r : res) {
            votos = listarVotos(r.getIdRest());

            resultlist.add(new Resultado(r.getNome(), votos));

        }
        return resultlist;
    }

    public void encerra() {
        List<Resultado> result = listarResultado();

        int votos = 0;
        String restaurante = null;

        //Não faz nada se só tiver uma opção de restaurante
        if (result.size() == 1) {
            return;
        }

        for (int i = 0; i < result.size(); i++) {

            if (result.get(i).getVotos() > votos) {
                votos = result.get(i).getVotos();
                restaurante = result.get(i).getRestaurante();

            }

        }

        // Se não tem restaurante votado não faz nada
        if (restaurante == null) {
            return;
        }

        // marca o restaurante como votado do dia
        Restaurante r = buscarPorNome(restaurante);
        r.setAtivo(false);
        atualizar(r);

        List<Usuario> lusu = listarUsuarios();

        // zera a votação dos usuarios
        for (Usuario u : lusu) {
            u.setRestaurante(0);
            usuarioDAO.atualizar(u);
        }

    }

    @Override
    public List<Restaurante> listarRestaurantesInativos() {
        return this.restauranteDAO.listarRestaurantesInativos();
    }

}
