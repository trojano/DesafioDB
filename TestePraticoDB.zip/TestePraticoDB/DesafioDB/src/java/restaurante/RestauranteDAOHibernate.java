/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package restaurante;

import java.util.List;
import org.hibernate.Query;
import org.hibernate.Session;
import usuario.Usuario;

/**
 *
 * @author marcos
 */
public class RestauranteDAOHibernate implements RestauranteDAO {

    private Session session;

    public void setSession(Session session) {
        this.session = session;
    }

    @Override
    public void salvar(Restaurante rest) {
        this.session.save(rest);
    }

    @Override
    public void atualizar(Restaurante rest) {
        this.session.update(rest);
    }

    @Override
    public void excluir(Restaurante rest) {
        this.session.delete(rest);
    }

    @Override
    public Restaurante buscarPorNome(String nome) {
        String hql = "select u from Restaurante u where u.nome = :nome";
        Query consulta = (Query) this.session.createQuery(hql);
        consulta.setParameter("nome", nome);
        return (Restaurante) consulta.uniqueResult();
    }

    @Override
    public List<Usuario> listarUsuarios() {
        String hql = "select u from Usuario u";
        Query consulta = (Query) this.session.createQuery(hql);
        return consulta.list();
    }

    @Override
    public List<Restaurante> listarRestaurantes() {
        String hql = "select u from Restaurante u "
                + "where u.ativo = 1";
        Query consulta = (Query) this.session.createQuery(hql);
        return consulta.list();
    }

    @Override
    public int listarVotos(int rest) {
        String hql = "select count(idPessoa) from Usuario "
                + "where idRestaurante = :rest";
        Query consulta = (Query) this.session.createQuery(hql);
        consulta.setParameter("rest", rest);

        return Integer.parseInt(consulta.uniqueResult().toString());

    }

    @Override
    public List<Restaurante> listarRestaurantesInativos() {
        String hql = "select u from Restaurante u "
                + "where u.ativo = 0";
        Query consulta = (Query) this.session.createQuery(hql);
        return consulta.list();
    }

}
