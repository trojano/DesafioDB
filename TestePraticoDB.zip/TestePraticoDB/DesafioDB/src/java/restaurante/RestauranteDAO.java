/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package restaurante;

import java.util.List;
import usuario.Usuario;

/**
 *
 * @author marcos
 */
public interface RestauranteDAO {

    public void salvar(Restaurante rest);

    public void atualizar(Restaurante rest);

    public void excluir(Restaurante rest);

    public Restaurante buscarPorNome(String nome);

    public List<Usuario> listarUsuarios();

    public List<Restaurante> listarRestaurantes();

    public int listarVotos(int rest);

    public List<Restaurante> listarRestaurantesInativos();

}
